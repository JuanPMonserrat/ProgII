﻿namespace WebApiProgII.Models
{
    public class Moneda
    {
        public string Nombre { get; set; }
        public float ValorEnPesos { get; set; }
    }
}
