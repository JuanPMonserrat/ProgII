﻿namespace WebApiProgII.Models
{
    public class Producto
    {
        public int Codigo { get; set; }
        public string NombreProd { get; set; }
        public float Precio { get; set; }
    }
}
